const questions = [
{
    image: "gambar2_Bima(Werkudara).png",
    clues: ["Punya saudara Bima", "Senjata khas nya adalah Gada",
         "Dikenal dengan nama Werkudara"],
options: ["Arjuna", "Bima", "Yudhistira", "Nakula"],
correct: "Bima"
},
{
    image: "gambar2_Arjuna.png",
    clues: ["Punya saudara Bima", "Senjata nya adalah Panah",
         "Dikenal karna ada di serial Mahabharata"],
options: ["Arjuna", "Bima", "Yudhistira", "Nakula"],
correct: "Arjuna"
},
{
    image: "gambar6_Hanoman.png",
    clues: ["Punya wajah seperti Monyet", "Senjata khas nya adalah Gada",
         "Dikenal karna sebagai pelindung hewan"],
options: ["Arjuna", "Hanoman", "Yudhistira", "Nakula"],
correct: "Hanoman"
},
{
    image: "gambar7_Gatotkaca.png",
    clues: ["Punya Kisah di tanah nusantara", "Senjata khas nya adalah Gada",
         "Dikenal dalam legenda"],
options: ["Arjuna", "Bima", "Yudhistira", "Gatotkaca"],
correct: "Gatotkaca"
},
];
const questionsElement = document.getElementById("questions");
const optionsElement = document.getElementById("options");
const resultElement = document.getElementById("result");    
let currentQuestion = 0;

function loadQuestion() {
};