const questions = [
    {answer:"Bima",options:["Arjuna","Yudhistira","Nakula","Bima"],clues:["Punya saudara kembar bernama bima","Senjata khasnya adalah gada","Dikenal dengan nama Werkudara"]},
    {answer:"Arjuna",options:["Arjuna","Duryodana","karna","Sengkuni"],clues:["Putra Pandu dan Kunti","Ahli memanah","Favorit dalam pewayangan"]},
    {answer:"Duryodana",options:["Duryodana","Bima","Dursasana","Salya"],clues:["Raja Hastinapura","Putra Gandari","Korawa Tertua"]},
    {answer:"Yudhistira",options:["Bima","Yudhistira","Nakula","Arjuna"],clues:["Pandawa Tertua","Terkenal Jujur dan Adil","Bergelar Dharmaraja"]},
    {answer:"Hanoman",options:["Sugriwa","Jatayu","Subali","Hanoman"],clues:["Raja kawanan kera","Sekutu Rama dalam Ramayana","Putra Batara Bayu"]}
];

let current=0,score=0,clueIndex=0,timeLeft=15,interval,clueInterval;

function startGame(){
    localStorage.setItem("current",0);
    localStorage.setItem("score",0);
    window.location.href="game.html";
}

function goScore(){
    window.location.href="score.html";
}
function goHome(){
    window.location.href="home.html";
}

if(location.pathname.includes("game.html")) loadQuestion();
function loadQuestion(){
    current=parseInt(localStorage.getItem("current"))||0;
    score=parseInt(localStorage.getItem("score"))||0;
    if(current>=questions.length){
        localStorage.setItem("finalScore", score);
        location.href="score.html";return;
    }
    let q=questions[current];
    clueIndex=0;timeLeft=15;
    showClue();
    let html="";
    q.options.forEach(o=>{html+=`<button onclick="checkAnswer('${o}')">${o}</button>`});
    document.getElementById("answers").innerHTML=html;
    startTimer();rotateClues();
}

function showClue(){
    document.getElementById("clue").innerText=questions[current].clues[clueIndex];
}

function rotateClues(){
    clueInterval=setInterval(()=>{if(clueIndex<2){clueIndex++;showClue();}}, 3000);
}

function startTimer(){
    interval=setInterval(()=>{
        timeLeft--;
        document.getElementById("timer").innerText="Waktu: "+timeLeft;
        document.getElementById("progress").style.width=(timeLeft/15*100)+"%";
        if(timeLeft<=0)
            nextQuestion();
    }, 1000)
}

function checkAnswer(ans){
    let correct=questions[current].answer;
    if(ans===correct){
        if(clueIndex===0) score+=30;
        else if(clueIndex===1) score+=20;
    else score+=10;
    }
    nextQuestion();
}

function nextQuestion(){
    clearInterval(interval);clearInterval(clueInterval);
    current++;
    localStorage.setItem("current", current);
    localStorage.setItem("score", score);
    loadQuestion();
}

if(location.pathname.includes("score.html")){
    let final=localStorage.getItem("finalScore")||0;
    document.getElementById("finalScore").innerText=final;
    document.getElementById("result").innerText=final>=100?"Menang":"Game Over";
    showAllScores();
}

function saveScore(){
    let name=document.getElementById("playerName").value;
    let final=localStorage.getItem("finalScore");
    let scores=JSON.parse(localStorage.getItem("scores"))||[];
    scores.push({name,score:final});
    scores.sort((a,b)=>b.score-a.score);
    scores=scores.slice(0,5);
    localStorage.setItem("scores",JSON.stringify(scores));
    showAllScores();
}

function showAllScores(){
    let scores = JSON.parse(localStorage.getItem("scores"))||[];
    scores.sort((a, b) => b.score - a.score);
    let list="";
    scores.forEach((s,index)=>{list+=`<li>${index+1}. ${s.name} - ${s.score}</li>`});
    document.getElementById("scoreList").innerHTML=list;
}